<?php

return [
    'workspace' => 'Ruang kerja',
    'sidebar_label' => 'Navigasi dashboard',
    'open_menu' => 'Buka menu navigasi',
    'greeting' => 'Halo, :name',
    'view_shop' => 'Lihat Toko',
    'account' => 'Akun Saya',
    'menu' => [
        'overview' => 'Ringkasan',
        'my_products' => 'Produk Saya',
        'incoming_orders' => 'Pesanan Masuk',
        'orders' => 'Pesanan',
        'certificates' => 'Sertifikat',
        'shipping_services' => 'Layanan Pengiriman',
        'export_logistics' => 'Logistik Ekspor',
        'shop_profile' => 'Profil Toko',
        'farmers' => 'Petani',
        'products' => 'Produk',
        'market_prices' => 'Harga Pasar',
        'articles' => 'Artikel',
        'rfqs' => 'RFQ',
        'new_count' => ':count permintaan RFQ baru',
        'locations' => 'Lokasi Pengguna',
    ],
];